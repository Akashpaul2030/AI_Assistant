# Initialize endpoints package
